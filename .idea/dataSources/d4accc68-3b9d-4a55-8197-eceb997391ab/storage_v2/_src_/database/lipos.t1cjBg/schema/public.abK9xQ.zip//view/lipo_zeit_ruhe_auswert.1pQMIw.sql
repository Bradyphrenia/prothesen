CREATE VIEW lipo_zeit_ruhe_auswert AS
  SELECT min(lipo.idnr) AS id,
    avg(lipo.volt) AS volt_a,
    ((lipo."time" - ( SELECT min(lipo_1."time") AS min
           FROM lipo lipo_1)) / 60000) AS diff_m
   FROM lipo
  WHERE (lipo.use = false)
  GROUP BY ((lipo."time" - ( SELECT min(lipo_1."time") AS min
           FROM lipo lipo_1)) / 60000)
  ORDER BY ((lipo."time" - ( SELECT min(lipo_1."time") AS min
           FROM lipo lipo_1)) / 60000);

