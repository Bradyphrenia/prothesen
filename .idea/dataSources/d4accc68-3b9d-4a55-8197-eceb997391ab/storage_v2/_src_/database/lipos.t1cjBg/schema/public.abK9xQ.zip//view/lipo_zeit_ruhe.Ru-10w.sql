CREATE VIEW lipo_zeit_ruhe AS
  SELECT lipo.idnr,
    lipo."time",
    lipo.volt,
    lipo.use,
    ((lipo."time" - 30004) / 1000) AS diff,
    ((lipo."time" - 30004) / 60000) AS diff_m
   FROM lipo
  WHERE (lipo.use = false);

