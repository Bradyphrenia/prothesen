CREATE VIEW aktive_koenigin AS
  SELECT koenigin.id,
    koenigin.koenigin,
    koenigin.generation,
    koenigin.art_paarung,
    koenigin.rasse,
    koenigin.stamm,
    koenigin.linie,
    koenigin.jahr,
    koenigin.volk,
    koenigin.schlupftag,
    koenigin.eiablage,
    koenigin.zeichnung,
    koenigin.nummer,
    koenigin.bemerkungen,
    koenigin.zuechter,
    koenigin.belegstelle,
    koenigin.status
   FROM koenigin
  WHERE ((koenigin.status)::text = 'aktiv'::text)
  ORDER BY koenigin.volk;

