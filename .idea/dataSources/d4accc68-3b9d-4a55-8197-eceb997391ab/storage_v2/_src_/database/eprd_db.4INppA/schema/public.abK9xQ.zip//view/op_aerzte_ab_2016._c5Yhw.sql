CREATE VIEW op_aerzte_ab_2016 AS
  SELECT operation.arzt_nachname AS "Name",
    count(operation.id) AS "Anzahl"
   FROM operation
  WHERE ((operation.opdatum >= '2016-01-01'::date) AND (operation.opdatum <= '2017-12-31'::date))
  GROUP BY operation.arzt_nachname;

