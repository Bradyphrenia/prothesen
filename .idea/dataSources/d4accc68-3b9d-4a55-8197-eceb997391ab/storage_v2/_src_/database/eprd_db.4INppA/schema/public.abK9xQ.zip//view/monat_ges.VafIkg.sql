CREATE VIEW monat_ges AS
  SELECT operation.arzt_nachname,
    date_part('year'::text, operation.opdatum) AS opj,
    date_part('month'::text, operation.opdatum) AS opm,
    count(operation.id) AS anz
   FROM operation
  WHERE ((operation.opdatum >= '2015-01-01'::date) AND (operation.opdatum <= '2016-12-31'::date))
  GROUP BY operation.arzt_nachname, (date_part('year'::text, operation.opdatum)), (date_part('month'::text, operation.opdatum))
  ORDER BY operation.arzt_nachname, (date_part('year'::text, operation.opdatum)), (date_part('month'::text, operation.opdatum));

