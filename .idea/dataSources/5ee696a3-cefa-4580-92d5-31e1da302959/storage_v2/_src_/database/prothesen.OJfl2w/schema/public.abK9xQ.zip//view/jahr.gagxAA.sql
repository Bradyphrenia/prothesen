create view jahr
            (id, patientennummer, prothesenart, prothesentyp, proximal, distal, seite, wechseleingriff, praeop_roentgen,
             postop_roentgen, fraktur, planung, opdatum, operateur, assistenz, op_zeiten, infektion, luxation,
             inklinationswinkel, trochanterabriss, fissuren, thrombose_embolie, sterblichkeit, neurologie,
             dokumentation, memo, knochenverankert, periprothetisch, reintervention, abweichung, ct, ab_imp_art,
             ab_imp_groesse, ab_stab, ab_blutung, ab_praeop, ab_operation, ab_anaesthesie, spaet_infekt, einweiser,
             neunzig_tage, kniewinkel_prae, kniewinkel_post, vierundzwanzig_plus, oak)
as
SELECT prothesen.id,
       prothesen.patientennummer,
       prothesen.prothesenart,
       prothesen.prothesentyp,
       prothesen.proximal,
       prothesen.distal,
       prothesen.seite,
       prothesen.wechseleingriff,
       prothesen.praeop_roentgen,
       prothesen.postop_roentgen,
       prothesen.fraktur,
       prothesen.planung,
       prothesen.opdatum,
       prothesen.operateur,
       prothesen.assistenz,
       prothesen.op_zeiten,
       prothesen.infektion,
       prothesen.luxation,
       prothesen.inklinationswinkel,
       prothesen.trochanterabriss,
       prothesen.fissuren,
       prothesen.thrombose_embolie,
       prothesen.sterblichkeit,
       prothesen.neurologie,
       prothesen.dokumentation,
       prothesen.memo,
       prothesen.knochenverankert,
       prothesen.periprothetisch,
       prothesen.reintervention,
       prothesen.abweichung,
       prothesen.ct,
       prothesen.ab_imp_art,
       prothesen.ab_imp_groesse,
       prothesen.ab_stab,
       prothesen.ab_blutung,
       prothesen.ab_praeop,
       prothesen.ab_operation,
       prothesen.ab_anaesthesie,
       prothesen.spaet_infekt,
       prothesen.einweiser,
       prothesen.neunzig_tage,
       prothesen.kniewinkel_prae,
       prothesen.kniewinkel_post,
       prothesen.vierundzwanzig_plus,
       prothesen.oak
FROM prothesen
WHERE prothesen.opdatum >= '2019-01-01 00:00:00'::timestamp without time zone
  AND prothesen.opdatum <= '2019-12-31 00:00:00'::timestamp without time zone
  AND prothesen.dokumentation = true;

alter table jahr
    owner to postgres;

